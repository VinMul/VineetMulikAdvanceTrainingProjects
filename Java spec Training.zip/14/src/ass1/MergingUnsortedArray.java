package ass1;
import java.util.*;
public class MergingUnsortedArray {
    int data;
    MergingUnsortedArray next;
    MergingUnsortedArray(int d) {data = d;
                 next = null;}
}
     
class MergeLists
{
	MergingUnsortedArray head;
 

public void addToTheLast(MergingUnsortedArray node)
{
    if (head == null)
    {
        head = node;
    }
    else
    {
    	MergingUnsortedArray temp = head;
        while (temp.next != null)
            temp = temp.next;
        temp.next = node;
    }
}
 

void printList()
{
	MergingUnsortedArray temp = head;
    while (temp != null)
    {
        System.out.print(temp.data + " ");
        temp = temp.next;
    }
    System.out.println();
}
public static void main(String args[])
{
    
    MergeLists llist1 = new MergeLists();
    MergeLists llist2 = new MergeLists();
     
    
    llist1.addToTheLast(new MergingUnsortedArray(10));
    llist1.addToTheLast(new MergingUnsortedArray(5));
    llist1.addToTheLast(new MergingUnsortedArray(15));
     
    
    llist2.addToTheLast(new MergingUnsortedArray(20));
    llist2.addToTheLast(new MergingUnsortedArray(2));
    llist2.addToTheLast(new MergingUnsortedArray(3));
     
     
    llist1.head = new Gfg().sortedMerge(llist1.head,
                                        llist2.head);
    llist1.printList();    
     
}
}
 
class Gfg
{

	MergingUnsortedArray sortedMerge(MergingUnsortedArray headA,MergingUnsortedArray headB)
{
     
    
		MergingUnsortedArray dummyNode = new MergingUnsortedArray(0);
     
    
		MergingUnsortedArray tail = dummyNode;
    while(true)
    {
         
       
        if(headA == null)
        {
            tail.next = headB;
            break;
        }
        if(headB == null)
        {
            tail.next = headA;
            break;
        }
         
       
        if(headA.data <= headB.data)
        {
            tail.next = headA;
            headA = headA.next;
        }
        else
        {
            tail.next = headB;
            headB = headB.next;
        }
         
        
        tail = tail.next;
    }
    return dummyNode.next;
}
}
