package ass1;
import java.util.Scanner;
public class Cmdline {

	 public static void main(String[] args) {  
	     
	     Scanner sc = new Scanner(System.in);  
	       
	     System.out.println("Please Enter First Number = ");  
	    
	     int firstNumber = sc.nextInt();  
	     // Promoting for second user input   
	     System.out.println("Please Enter Second Number = ");  
	     
	     int secondNumber = sc.nextInt();  
	     // Initializing sum=0 to store temporary value.  
	     int sum = 0;  
	    
	     System.out.print(firstNumber + " " + secondNumber + " ");  
	     
	     for (int counter = 0; counter < 13; counter++) {  
	      
	       sum = firstNumber + secondNumber;  
	       
	       System.out.print(sum + " ");  
	       
	       firstNumber = secondNumber;  
	       secondNumber = sum;  
	     }  
	   }  
	 }  
