package ass1;

public class Reverse2 {

	public static void main(String[] args) {
        
        String str = "Java is Simple";
        StringBuffer sb = new StringBuffer(str);
        sb.reverse();
        System.out.println(sb);
    }
}