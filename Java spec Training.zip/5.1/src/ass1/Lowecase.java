package ass1;
import java.lang.String;
public class Lowecase {

	public static void main(String[] args) {
        String str = "JAVA IS SIMPLE";
        System.out.println(str.toLowerCase());
    }
}
