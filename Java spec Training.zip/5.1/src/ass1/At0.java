package ass1;
import java.lang.String;
public class At0 {

	public static void main(String[] args) {
        String str = "Java is Simple";
        System.out.println(str.charAt(0));
    }
}
