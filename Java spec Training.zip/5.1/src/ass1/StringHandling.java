package ass1;
import java.lang.String;
public class StringHandling {

	public static void main(String[] args) {
        String str = "java is simple";
        System.out.println(str.toUpperCase());
    }
}
