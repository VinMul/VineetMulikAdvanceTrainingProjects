package ass1;

public class reverse {

	public static void main(String[] args) {
        
        String str = "AVAJ si elpmiS";
        StringBuffer sb = new StringBuffer(str);
        sb.reverse();
        System.out.println(sb);
    }
}
