package ass1;
import java.lang.String;
public class Length {

	public static void main(String[] args) {
        String str = "javaissimple";
        System.out.println(str.length());
    }
}
