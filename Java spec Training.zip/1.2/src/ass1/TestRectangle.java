package ass1;
public class Rectangle1{
    
    double length, width;

    Rectangle1()
    
    {
        length = 1;
        
        width = 1;
        
    }
    
    
    Rectangle1(double length, double width)
            
            
    {
        this.length = length;
        
        this.width  = width;
        
    }
    
    // define a method
    double getArea()
            
    {
        return (length * width);
        
    }
    
    double getPerimeter()
            
    {
        return (2 * (length + width));
    }
}

public class TestRectangle {

	public static void main(String[] args){
        
        
        Rectangle1 rect1 = new Rectangle1();
        
        
        Rectangle rect2= new Rectangle(10.0,4.0);
        
        System.out.println("Area of first object="+rect1.getArea());
        
        System.out.println("Perimeter of first object="+rect1.getPerimeter());
        
        System.out.println("Area of second object="+rect2.getArea());
        
        System.out.println("Perimeter of second object="+rect2.getPerimeter());
   }
    
}
