module EvenNumber {
}